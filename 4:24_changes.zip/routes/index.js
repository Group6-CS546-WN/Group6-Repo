import businessesRoutes from './businesses.js';
import reviewsRoutes from './reviews.js';
import usersRoutes from './users.js';
import projectsRoutes from './projects.js';
import TipsGuidesRoutes from './TipsGuides.js';
import forumRoutes from './forum.js';
import productsRoutes from './products.js';
import productReviewsRoutes from './productReviews.js';
import calculatorRoutes from './calculator.js';


import path from 'path';
import {static as staticDir} from 'express';

const constructorMethod = (app) => {
  app.use('/businesses', businessesRoutes);
  app.use('/reviews', reviewsRoutes);
  app.use('/users', usersRoutes);
  app.use('/projects', projectsRoutes);
  app.use('/TipsGuides', TipsGuidesRoutes);
  app.use('/forum', forumRoutes);
  app.use('/products', productsRoutes);
  app.use('/productReviews', productReviewsRoutes);
  app.use('/calculator', calculatorRoutes);
  app.get('/about', (req, res) => {
    res.sendFile(path.resolve('static/about.html'));


  });

  app.use('*', (req, res) => {
    res.status(404).json({error: 'Route Not found'});
  });


};

export default constructorMethod;
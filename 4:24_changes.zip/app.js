import express from 'express';
const app = express();
import exphbs from 'express-handlebars';
import configRoutes from './routes/index.js';
//import middleware from './middleware.js';
const staticDir = express.static('public');

// const handlebarsInstance = exphbs.create({
//   defaultLayout: 'main',
//   // Specify helpers which are only registered on this instance.
//   helpers: {
//     asJSON: (obj, spacing) => {
//       if (typeof spacing === 'number')
//         return new Handlebars.SafeString(JSON.stringify(obj, null, spacing));

//       return new Handlebars.SafeString(JSON.stringify(obj));
//     },

//     partialsDir: ['views/partials/']
//   }
// });

const rewriteUnsupportedBrowserMethods = (req, res, next) => {
  // If the user posts to the server with a property called _method, rewrite the request's method
  // To be that method; so if they post _method=PUT you can now allow browsers to POST to a route that gets
  // rewritten in this middleware to a PUT route
  if (req.body && req.body._method) {
    req.method = req.body._method;
    delete req.body._method;
  }

  // let the next middleware run:
  next();
};

app.use(express.json());
app.use('/public', express.static('public'));
app.use(express.urlencoded({extended: true}));
app.use(rewriteUnsupportedBrowserMethods)
app.engine('handlebars', exphbs.engine({defaultLayout: 'main',
helpers: {
  asJSON: (obj, spacing) => {
    if (typeof spacing === 'number')
      return new Handlebars.SafeString(JSON.stringify(obj, null, spacing));

    return new Handlebars.SafeString(JSON.stringify(obj));
  },

  partialsDir: ['views/partials/']
}
}));
// layoutsDir: __dirname + '/views/layouts/',
// helpers: {
//     extend: function(name, context) {
//         return context.fn(this);
//     },
//     content: function(name, context) {
//         return context.fn(this);
//     }
// } }));


app.set('view engine', 'handlebars');

// app.use(
//   session({
//       name: 'AuthState',
//       secret: "This is a secret.. shhh don't tell anyone",
//       saveUninitialized: false,
//       resave: false,
//       cookie: {maxAge: 60000}
//   }));

  // Static files
//app.use('/public', express.static('public'));


// app.get('/', middleware.rootRedirectMiddleware, (req, res) => {
//   res.send('Root Route');
// });

// app.get('/login', middleware.blockAuthenticatedAccess, (req, res) => {
//   res.render('login');
// });

// app.get('/register', middleware.blockAuthenticatedAccess, (req, res) => {
//   res.render('register');
// });

// app.get('/protected', middleware.ensureAuthenticated, (req, res) => {
//   let userAdmin = req.session.user.role === 'admin' ? true : false;
//   res.render('protected', { firstName: req.session.user.firstName, lastName: req.session.user.lastName, currentTime: new Date().toUTCString(), role: req.session.user.role, isAdmin: userAdmin });
// });

// app.get('/admin', middleware.ensureAdmin, (req, res) => {
//   res.render('admin', { firstName: req.session.user.firstName, lastName: req.session.user.lastName, currentTime: new Date().toUTCString()});
// });



configRoutes(app);


app.listen(3000, () => {
  console.log("We've now got a server!");
  console.log('Your routes will be running on http://localhost:3000');
});
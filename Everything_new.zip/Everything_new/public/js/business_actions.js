document.addEventListener('DOMContentLoaded', function () {
    // Update business using AJAX
    document.getElementById('update-form').onsubmit = function(e) {
        e.preventDefault();
        const businessId = this.getAttribute('data-id');
        const formData = new FormData(this);
        fetch('/businesses/' + businessId, {
            method: 'PUT', // Changed from 'POST' to 'PUT'
            contentType: 'application/json',
            data: JSON.stringify({
                body: formData
              })
            
        })
        .then(response => {
            if (!response.ok) throw new Error('Network response was not ok');
            return response.json();
        })
        .then(data => {
            alert('Business updated successfully!');
            location.reload(); // Reload the page to see the updated data
        })
        .catch(error => alert('Error updating business: ' + error));
    };

    // Delete business using AJAX
    document.getElementById('delete-button').onclick = function() {
        const businessId = this.getAttribute('data-id');
        if(confirm('Are you sure you want to delete this business?')) {
            fetch('/businesses/' + businessId, {
                method: 'DELETE',
                contentType: 'application/json',
            })
            .then(response => {
                if (!response.ok) throw new Error('Network response was not ok');
                return response.json();
            })
            .then(data => {
                alert('Business deleted successfully!');
                window.location.href = '/businesses'; // Redirect to the business list
            })
            .catch(error => alert('Error deleting business: ' + error));
        }
    };
});
